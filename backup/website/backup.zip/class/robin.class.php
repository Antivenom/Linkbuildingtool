<?php
class Robin {
    private $db;

    function __construct($objDB_con) {
        $this->db = $objDB_con;

    }

    function get_data($url) {
        $ch = curl_init();
        $timeout = 5;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $data = curl_exec($ch);

        curl_close($ch);
        return $data;
    }


    public function getSubmissions() {
        $stmt = $this->db->prepare("
            SELECT submissions.link_url, campaigns.url
            FROM submissions
            INNER JOIN campaigns ON submissions.campaigns_id = campaigns.id
			WHERE
              (submissions.status = 'accepted'
              OR
              submissions.status = 'submitted')
              AND
              campaigns.bot_enabled = 1
        ");

        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    public function execute($targetHtmlPage, $link)
    {

        $urlPos = stripos($targetHtmlPage, $link);

        if ($urlPos === false) {
            echo '<br />The URL could not be found.<br /> Changing the status on this submission.<br />';
        } else {
            echo '<br />Success! The URL was found on the website.<br /></div>';
            $this->updateSubmissions();

            $linkStart = strrpos($targetHtmlPage, '<a', -1 * (strlen($targetHtmlPage) - $urlPos));
            $linkEnd = strpos($targetHtmlPage, '</a>', $urlPos);
            if ($linkStart === false) {
                echo '&lt;a&gt; Tag not found. <br />';
            } else {
                echo '&lt;a&gt; Tag found. resuming &lt;/a&gt; check. <br />';
                $this->updateSubmissions();
            }
            if ($linkEnd === false) {
                echo '&lt;/a&gt; Tag not found. <br />';
            } else {
                echo '&lt;/a&gt; Tag found. resuming Nofollow check. <br />';
            }

            // is glitched, zet nu error ook al staat de nofollow aan de andere kant van de wereld.
            $noFollow = strpos($targetHtmlPage, 'rel="nofollow"', $linkStart);
            if ($noFollow === false || $noFollow < $linkEnd) {
                echo 'Success: Nofollow tag was NOT found. <br />';
            } else {
                echo 'Error: Nofollow tag was found. <br />';
            }
        }
    }

    public function updateSubmissions() {
        $stmt = $this->db->prepare("
            UPDATE submissions
            SET
              bot_updated = CURRENT_TIME
            WHERE
              (submissions.status = 'accepted'
              OR
              submissions.status = 'submitted')
        ");

        $stmt->execute();
    }

    function save() {

    }
}