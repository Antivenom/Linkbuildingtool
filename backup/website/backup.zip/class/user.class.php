<?php	
class USER
{
	private $db;
	
	function __construct($objDB_con)
	{
		$this->db = $objDB_con;
	}
	
	/*
			USER RELATED CODE
			USER RELATED CODE
			USER RELATED CODE	
			USER RELATED CODE
			USER RELATED CODE
			USER RELATED CODE
	*/
	
	public function register($strUsername, $strFirstName, $strLastName, $strUserMail, $Password)
	{
		try
		{
			$strNewPassword = md5($Password);
			
			$stmt = $this->db->prepare("
				INSERT INTO users(
					username,
					password,	
					email,
					firstname,
					lastname
				) VALUES (
					:username,
					:password,
					:email,
					:firstname,
					:lastname
				)
			");
			
			$stmt->bindparam(':username', $strUsername);
			$stmt->bindparam(':password', $Password);
			$stmt->bindparam(':email', $strUserMail);
			$stmt->bindparam(':firstname', $strFirstName);
			$stmt->bindparam(':lastname', $strLastName);
			
			$stmt->execute();
			
			return $stmt;
			
		} catch(PDOException $e) {
			echo $e->getMessage();
		}
	}
	
	public function addUser($UserID, $CustomerID, $email, $password, $firstname, $lastName)
	{
		try
		{
			$hashPassword = md5($password);
			$zeroInt = 0;
			
			$stmt = $this->db->prepare("
				INSERT INTO users(
					customers_id,
					email,
					password,
					firstname,
					lastname,
					superuser
				) VALUES (
					:customer_id,
					:email,
					:password,
					:firstname,
					:lastname,
					:superuser
				)
			");
			
			$stmt->bindParam(':customer_id', $CustomerID);
			$stmt->bindParam(':email', $email);
			$stmt->bindParam(':password', $hashPassword);
			$stmt->bindParam(':firstname', $firstname);
			$stmt->bindParam(':lastname', $lastName);
			$stmt->bindParam(':superuser', $zeroInt);
			
			$stmt->execute();
			
			return $stmt;
		} catch (PDOException $e) {
			echo $e->getMessage();
		}
	}
	
	public function login($strUserMail, $Password)
	{
		try
		{
			$stmt = $this->db->prepare("
				SELECT *
				FROM users
				WHERE
					email = :email
			");
			
			$stmt->execute(array(
				':email' => $strUserMail
			));
			
			$userRow = $stmt->fetch(PDO::FETCH_ASSOC);
									
			if($stmt->rowCount() > 0)
			{
				if(md5($Password) == $userRow['password'])
				{
					$_SESSION['UserID'] = $userRow['id'];
					$_SESSION['CustomerID'] = $userRow['customers_id'];
					return true;
				} else {
					return false;
				}
			}
		} catch(PDOException $e) {
			echo $e->getMessage();
		}
	}
	
	public function changePassword($userID, $oldPassword, $newPassword, $repeatedNewPassword)
	{
		$stmt = $this->db->prepare("
			SELECT password
			FROM users
			WHERE
				id = :id
		");
		
		$stmt->bindValue(':id', $userID);
		$stmt->execute();
		$passwordResult = $stmt->fetch(PDO::FETCH_ASSOC);
		
		$fetchedPass = $passwordResult['password'];
		
		if($oldPassword === $fetchedPass)
		{
			if($newPassword === $repeatedNewPassword)
			{
				$stmtChange = $this->db->prepare("
					UPDATE users
					SET
						password = :password
					WHERE
						id = ".$_SESSION['UserID']."
				");
				
				$stmtChange->bindParam(':password', $newPassword);
				$stmtChange->execute();
				
				$this->redirect('../offline/changed.html');
				return true;
			} else {
			return false;
		}
		} else {
			return false;
		}
	}
	
	public function isLoggedIn()
	{
		if(isset($_SESSION['UserID']))
		{
			return true;
		} else {
			return false;
		}
	}
	
	public function redirect($url)
	{
		header("Location: $url");
	}
	
	public function logout()
	{
		session_destroy();
		
		unset($_SESSION['UserID']);
		unset($_SESSION['CustomerID']);
		
		return true;
	}
	
	public function getUser($UserID)
	{
		$getUser = $this->db->prepare("
			SELECT *
			FROM users
			WHERE
				id = :id
		");
		
		$getUser->bindParam(':id', $UserID);
		$getUser->execute();
		$User = $getUser->fetch(PDO::FETCH_ASSOC);
		return $User;
	}
	
	public function getAllUsers($CustomerID)
	{
		$getUsers = $this->db->prepare("
			SELECT *
			FROM users
			WHERE
				customers_id = :customersid
		");
		
		$getUsers->bindParam(':customersid', $CustomerID);
		$getUsers->execute();
		
		$fetchedUsers = $getUsers->fetchAll(PDO::FETCH_ASSOC);
		return $fetchedUsers;
	}
	
	public function deleteUser($UserID)
	{
		$stmt = $this->db->prepare("
			DELETE
			FROM users
			WHERE
				id = :id
		");
		
		$stmt->bindValue(':id', $UserID);
		$stmt->execute();
	}
	
	public function updateUser($UserID, $email, $firstname, $lastname, $SuperUser, $active)
	{
		
		$stmt = $this->db->prepare("
			UPDATE users 
			SET
				email = :email,
				firstname = :firstname,
				lastname = :lastname,
				superuser = :superuser,
				active = :active
			WHERE
				id = :id
		");
		
		$stmt->bindValue(':id', $UserID);
		$stmt->bindValue(':email', $email);
		$stmt->bindValue(':firstname', $firstname);
		$stmt->bindValue(':lastname', $lastname);
		$stmt->bindValue(':superuser', $SuperUser);
		$stmt->bindValue(':active', $active);
		
		$stmt->execute();
		
		return $stmt;
	}
	
	/*
			CAMPAIGN RELATED CODE
			CAMPAIGN RELATED CODE
			CAMPAIGN RELATED CODE	
			CAMPAIGN RELATED CODE
			CAMPAIGN RELATED CODE
			CAMPAIGN RELATED CODE
	*/
	
	public function registerCampaign($CustomerID, $name, $email, $emailtemplate, $url, $category, $title, $description, $owner, $active, $bot, $linksiteDATA)
	{
		try
		{
			$stmt = $this->db->prepare("
				INSERT INTO campaigns(
					customer_id,
					name,
					email,
					email_template,
					url,
					category,
					title,
					description,
					owner,
					active,
					bot_enabled
				) VALUES (
					:customerid,
					:name,
					:email,
					:emailtemplate,
					:url,
					:category,
					:title,
					:description,
					:owner,
					:active,
					:botenabled
				)
			");
			
			$stmt->bindParam(':customerid', $CustomerID);
			$stmt->bindParam(':name', $name);
			$stmt->bindParam(':email', $email);
			$stmt->bindParam(':emailtemplate', $emailtemplate);
			$stmt->bindParam(':url', $url);
			$stmt->bindParam(':category', $category);
			$stmt->bindParam(':title', $title);
			$stmt->bindParam(':description', $description);
			$stmt->bindParam(':owner', $owner);
			$stmt->bindParam(':active', $active);
			$stmt->bindParam(':botenabled', $bot);
			
			$stmt->execute();
			
			if($stmt){
				$campaignID = $this->db->lastInsertId();
				foreach($linksiteDATA as $data){
					if(!$this->addSubmission($campaignID, $data['id'], $data['url'], null, 'Not Submitted')){
						return false;
					}
				}
				return true;
			}

			
			return $stmt;
		} catch(PDOException $e) {
			echo $e->getMessage();
		}
	}
	
	public function deleteCampaign($CampaignID)
	{
		$stmt = $this->db->prepare("
			DELETE
			FROM campaigns
			WHERE
				id = :id
		");
		
		$stmt->bindParam(':id', $CampaignID);
		$stmt->execute();
	}
	
	public function getCampaigns($CustomerID)
	{
		$stmt = $this->db->prepare("
			SELECT *
			FROM campaigns
			WHERE
				customer_id = :customerID
		");
		
		$stmt->bindValue(':customerID', $CustomerID);
		$stmt->execute();
		$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
		
		return $results;
	
	}
	
	public function getCampaign($CampaignID)
	{
		$stmt = $this->db->prepare("
			SELECT *
			FROM campaigns
			WHERE
				id = :id
		");
		
		$stmt->bindValue(':id', $CampaignID);
		$stmt->execute();
		$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
		
		return $results;
	}
	
	public function getCampaign2($CampaignID)
	{
		$stmt = $this->db->prepare("
			SELECT *
			FROM campaigns
			WHERE
				id = :id
		");
		
		$stmt->bindValue(':id', $CampaignID);
		$stmt->execute();
		$results = $stmt->fetch(PDO::FETCH_ASSOC);
		
		return $results;
	}
	
	public function updateCampaign($name, $email, $emailtemplate, $url, $category, $title, $description, $owner, $id, $active, $bot)
	{
		$stmt = $this->db->prepare("
			UPDATE campaigns
			SET
				name = :name,
				email = :email,
				email_template = :emailtemplate,
				url = :url,
				category = :category,
				title = :title,
				description = :description,
				owner = :owner,
				active = :active,
				bot_enabled = :bot
			WHERE
				id = :id
		");
		
		$stmt->bindParam(':name', $name);
		$stmt->bindParam(':email', $email);
		$stmt->bindParam(':emailtemplate', $emailtemplate);
		$stmt->bindParam(':url', $url);
		$stmt->bindParam(':category', $category);
		$stmt->bindParam(':title', $title);
		$stmt->bindParam(':description', $description);
		$stmt->bindParam(':owner', $owner);
		$stmt->bindParam(':active', $active);
		$stmt->bindParam(':bot', $bot);
		
		$stmt->bindParam(':id', $id);
		
		$stmt->execute();
		
		return $stmt;
	}
	
	public function fetchAllCampaigns() {

		$sqlQuery = $this->db->prepare("SELECT * FROM campaigns");
		$sqlQuery->execute();

		return $sqlQuery->fetchAll();
	}
	
	public function countAllCampaigns($CustomerID)
	{
		$stmt = $this->db->prepare("SELECT id FROM campaigns WHERE customer_id = :id");
		$stmt->bindParam(':id', $CustomerID);
		$stmt->execute();
		
		$count = $stmt->rowCount();
		return $count;
	}
	
	/*
			LINKSITE RELATED CODE
			LINKSITE RELATED CODE
			LINKSITE RELATED CODE	
			LINKSITE RELATED CODE
			LINKSITE RELATED CODE
			LINKSITE RELATED CODE
	*/
	
	public function registerLinkSite($CustomerID, $name, $type, $category, $rating, $comment, $url, $submitpage, $costs, $costs_amount, $backlink, $owner, $owneremail, $campaignIDs)
	{
		
		try
		{
			$stmt = $this->db->prepare("
				INSERT INTO linksites(
					customer_id,
					name,
					type,
					category,
					rating,
					comment,
					url,
					submit_page,
					costs,
					costs_amount,
					backlink,
					owner,
					owner_email
				) VALUES (
					:customerid,
					:name,
					:type,
					:category,
					:rating,
					:comment,
					:url,
					:submit_page,
					:costs,
					:costs_amount,
					:backlink,
					:owner,
					:owner_email
				)
			");
	
			$stmt->bindParam(':customerid', $CustomerID);
			$stmt->bindParam(':name', $name);
			$stmt->bindParam(':type', $type);
			$stmt->bindParam(':category', $category);
			$stmt->bindParam(':rating', $rating);
			$stmt->bindParam(':comment', $comment);
			$stmt->bindParam(':url', $url);
			$stmt->bindParam(':submit_page', $submitpage);
			$stmt->bindParam(':costs', $costs);
			$stmt->bindParam(':costs_amount', $costs_amount);
			$stmt->bindParam(':backlink', $backlink);
			$stmt->bindParam(':owner', $owner);
			$stmt->bindParam(':owner_email', $owneremail);
			
			$stmt->execute();
			
			if($stmt){
				$linksiteID = $this->db->lastInsertId();
				foreach($campaignIDs as $id){
					if(!$this->addSubmission($id, $linksiteID, $url, null, 'Not Submitted')){
						return false;
					}
				}
				return true;
			}
		
			
		} catch(PDOException $e) {
			echo $e->getMessage();
		}
	}
	
	public function updateLinksite($CustomerID, $id, $name, $type, $category, $rating, $comment, $url, $submitpage, $costs, $costs_amount, $backlink, $owner, $owneremail, $rip_status)
	{
		
		$stmt = $this->db->prepare("
			UPDATE linksites 
			SET
				customer_id = :customerid,
				name = :name,
				type = :type,
				category = :category,
				rating = :rating,
				comment = :comment,
				url = :url,
				submitpage = :submitpage,
				costs = :costs,
				costs_amount = :costs_amount,
				backlink = :backlink,
				owner = :owner,
				owner_email = :owner_email,
				rip_status = :ripstatus
			WHERE
				id = :id
		");
		
		$stmt->bindParam(':customerid', $CustomerID);
		$stmt->bindParam(':name', $name);
		$stmt->bindParam(':type', $type);
		$stmt->bindParam(':category', $category);
		$stmt->bindParam(':rating', $rating);
		$stmt->bindParam(':comment', $comment);
		$stmt->bindParam(':url', $url);
		$stmt->bindParam(':submit_page', $submitpage);
		$stmt->bindParam(':costs', $costs);
		$stmt->bindParam(':costs_amount', $costs_amount);
		$stmt->bindParam(':backlink', $backlink);
		$stmt->bindParam(':owner', $owner);
		$stmt->bindParam(':owner_email', $owneremail);
		$stmt->bindParam(':ripstatus', $rip_status);
		$stmt->bindParam('id', $id);
		
		$stmt->execute();
	}
	
	public function deleteLinksite($LinksiteID)
	{
		$stmt = $this->db->prepare("
			DELETE
			FROM linksites
			WHERE
				id = :id
		");
		
		$stmt->bindValue(':id', $LinksiteID);
		$stmt->execute();
	}
	
	public function getLinksites($CustomerID)
	{
		$stmt = $this->db->prepare("
			SELECT *
			FROM linksites
			WHERE
				customer_id = :customerID
		");
		
		$stmt->bindValue(':customerID', $CustomerID);
		$stmt->execute();
		
		$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
		
		return $results;
	}

	public function fetchAllLinksites($CustomerID)
	{
		$stmt = $this->db->prepare("
			SELECT url
			FROM linksites
			WHERE
				customer_id = :customerID
		");

		$stmt->bindValue(':customerID', $CustomerID);
		$stmt->execute();

		$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

		return $results;
	}
		
	public function getLinkSite($LinksiteID)
	{
		$stmt = $this->db->prepare("
			SELECT *
			FROM linksites
			WHERE
				id = :id
		");
		
		$stmt->bindValue(':id', $LinksiteID);
		$stmt->execute();
		$results = $stmt->fetch(PDO::FETCH_ASSOC);
		
		return $results;
	}
	
	public function countAllLinksites($CustomerID)
	{
		$stmt = $this->db->prepare("SELECT id FROM linksites WHERE customer_id = :id");
		$stmt->bindParam(':id', $CustomerID);
		$stmt->execute();
		
		$count = $stmt->rowCount();
		return $count;
	}
	
	/*
			SUBMISSION RELATED CODE
			SUBMISSION RELATED CODE
			SUBMISSION RELATED CODE	
			SUBMISSION RELATED CODE
			SUBMISSION RELATED CODE
			SUBMISSION RELATED CODE
	*/
	public function addSubmission($CampaignID, $LinksiteID, $LinkUrl, $Comment, $Status)
	{
		$stmt = $this->db->prepare("
			INSERT INTO submissions(
				campaigns_id,
				linksites_id,
				link_url,
				comment,
				status
			) VALUES (
				:campaignid,
				:linksiteid,
				:linkurl,
				:comment,
				:status
			)	
		");
		
		$stmt->bindParam(':campaignid', $CampaignID);
		$stmt->bindParam(':linksiteid', $LinksiteID);
		$stmt->bindParam(':linkurl', $LinkUrl);
		$stmt->bindParam(':comment', $Comment);
		$stmt->bindParam(':status', $Status);
		
		$stmt->execute();
		
		return $stmt;
	}
	
	public function getSubmissions($CampaignID)
	{
		$stmt = $this->db->prepare("
			SELECT linksites.*, submissions.* FROM submissions
			INNER JOIN linksites ON submissions.linksites_id = linksites.id
			WHERE submissions.campaigns_id = :campaignID
		");
		
		$stmt->bindValue(':campaignID', $CampaignID);
		$stmt->execute();
		$linksites = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $linksites;
	}
	
	public function deleteSubmission($SubmissionID)
	{
		$stmt = $this->db->prepare("
			DELETE 
			FROM submissions
			WHERE
				id = :id
		");
		
		$stmt->bindParam(':id', $SubmissionID);
		$stmt->execute();
	}

	public function getSubmissionStatus($CampaignID)
	{
		$stmt = $this->db->prepare("
			SELECT status
			FROM submissions
			WHERE campaigns_id = :campaignid
		");

		$stmt->bindParam(':campaignid', $CampaignID);
		$stmt->execute();

		$result = $stmt->fetch(PDO::FETCH_ASSOC);
		return $result;
	}
	
	/*
			CUSTOMER RELATED CODE
			CUSTOMER RELATED CODE
			CUSTOMER RELATED CODE	
			CUSTOMER RELATED CODE
			CUSTOMER RELATED CODE
			CUSTOMER RELATED CODE
	*/
	
	public function getCustomerID($UserID)
	{
		
		$getCustomer = $this->db->prepare("
			SELECT *
			FROM customers
			WHERE
				id = :id
		");
		
		$getCustomer->bindParam(':ID', $UserID);
		
		$CustomerID = $getCustomer->execute();
		
		return $CustomerID;
	}
}