<?php

require_once '../config.php';

 $submissions = $robin->getSubmissions();

foreach ($submissions as $submission) {

    $html = $robin->get_data($submission['link_url']);

    $robin->execute($html, $submission['url']);
}