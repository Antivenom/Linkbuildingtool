<?php

require_once '../config.php';

if(!isset($_SESSION['UserID']))
{
    header('Location: ../offline/offline.html');
} else {
    $UserID = $_SESSION['UserID'];
    $noPerms = !$hasPermission->isSuperuser($UserID);

    if($noPerms)
    {
        $objUser->redirect('../offline/denied.html');
    } else {
        // robin
        


    }
}

?>
<!DOCTYPE html>
<html>
    <head>
        <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css' />
        <link href="http://fonts.googleapis.com/css?family=Raleway:400,300,700" rel="stylesheet" type="text/css">
        <link rel="stylesheet" type="text/css" href="css/normalize.css" />
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/ns-default.css" />
        <link rel="stylesheet" type="text/css" href="css/ns-style-growl.css" />
        <script src="js/modernizr.custom.js"></script>
        <script type="text/javascript">
            var _gaq = _gaq || [];
            _gaq.push(['_setAccount', 'UA-7243260-2']);
            _gaq.push(['_trackPageview']);
            (function() {
                var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
                ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
                var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
            })();
        </script>
    </head>

    <body>
    <body class="color-1">
    <div class="container">
        <!-- Top Navigation -->
        <div class="codrops-top clearfix">
            <a class="codrops-icon codrops-icon-prev" href="http://tympanus.net/Development/SelectInspiration/"><span>Previous Demo</span></a>
            <a class="codrops-icon codrops-icon-drop" href="http://tympanus.net/codrops/?p=19415"><span>Back to the Codrops Article</span></a>
        </div>
        <header class="codrops-header">
            <h1>Notification Styles Inspiration <span>Simple ideas &amp; effects for website notifications</span></h1>
        </header>
        <div class="main clearfix">
            <div class="column">
                <p class="small">Click on the button to show the notification:</p>
                <button id="notification-trigger" class="progress-button">
                    <span class="content">Show Notification</span>
                    <span class="progress"></span>
                </button>
            </div>
            <div class="column">
                <nav class="codrops-demos">
                    <h3>Growl-like</h3>
                    <div>
                        <a class="current-demo" href="index.html">Scale</a>
                        <a href="growl-jelly.html">Jelly</a>
                        <a href="growl-slide.html">Slide in</a>
                        <a href="growl-genie.html">Genie</a>
                    </div>
                    <h3>Attached</h3>
                    <div>
                        <a href="attached-flip.html">Flip</a>
                        <a href="attached-bouncyflip.html">Bouncy Flip</a>
                    </div>
                    <h3>Top Bar</h3>
                    <div>
                        <a href="bar-slidetop.html">Slide On Top</a>
                        <a href="bar-exploader.html">Expanding Loader</a>
                    </div>
                    <h3>Other</h3>
                    <div>
                        <a href="other-cornerexpand.html">Corner Expand</a>
                        <a href="other-loadingcircle.html">Loading Circle</a>
                        <a href="other-boxspinner.html">Box Spinner</a>
                        <a href="other-thumbslider.html">Thumb Slider</a>
                    </div>
                </nav>
            </div>
        </div>
        <!-- Related demos -->
        <section class="related">
            <p>If you enjoyed this demo you might also like:</p>
            <a href="http://tympanus.net/Development/ProgressButtonStyles/">
                <img src="http://tympanus.net/codrops/wp-content/uploads/2013/12/ProgressButtonStyles-300x162.png" />
                <h3>Progress Button Styles</h3>
            </a>
            <a href="http://tympanus.net/Development/CreativeLoadingEffects/">
                <img src="http://tympanus.net/codrops/wp-content/uploads/2013/09/CreativeLoadingEffects-300x162.png" />
                <h3>Creative Loading Effects</h3>
            </a>
        </section>
    </div><!-- /container -->


    <script src="js/classie.js"></script>
    <script src="js/notificationFx.js"></script>
    <script>
        (function() {
            var svgshape = document.getElementById( 'notification-shape' ),
                bttn = document.getElementById( 'notification-trigger' );

            // make sure..
            bttn.disabled = false;

            bttn.addEventListener( 'click', function() {
                // create the notification
                var notification = new NotificationFx({
                    wrapper : svgshape,
                    message : '<p>Whatever you did, it was successful!</p>',
                    layout : 'other',
                    effect : 'loadingcircle',
                    ttl : 9000,
                    type : 'notice', // notice, warning or error
                    onClose : function() {
                        bttn.disabled = false;
                    }
                });

                // show the notification
                notification.show();

                // disable the button (for demo purposes only)
                this.disabled = true;
            } );
        })();
    </script>

    </body>
</html>
