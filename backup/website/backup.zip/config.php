<?php
session_start();

$strDB_host = "localhost";
$strDB_user = "testssit";
$strDB_pass = "f2j7f4Mx";
$strDB_name = "testssit_1";

$cName = session_name("Linkbuildingtool");

try
{
	$objDB_con = new PDO("mysql:host={$strDB_host};dbname={$strDB_name}",$strDB_user,$strDB_pass);
	$objDB_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e)
{
	echo $e->getMessage();
}

include_once 'class/user.class.php';
include_once 'class/permission.class.php';
include_once 'class/robin.class.php';
include_once 'class/backup.class.php';

$objUser = new USER($objDB_con);
$hasPermission = new Permission($objDB_con);
$robin = new Robin($objDB_con);
$backup = new Backup();