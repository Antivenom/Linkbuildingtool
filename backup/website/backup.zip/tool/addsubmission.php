<?php
	
require_once '../config.php';

if(!isset($_SESSION['UserID']))
{
	header('Location: ../offline/offline.html');
} else {
	if(isset($_POST['addsubmission']))
	{
		$CampaignID = $objUser->getCampaign($CustomerID);
		$LinksiteID = $objUser->getLinksite($LinksiteID);

		$LinkUrl = $_POST['linkurl'];
		$Comment = $_POST['comment'];
		
		$Status = $_POST['status'];
		
		if($objUser->addSubmission($CampaignID, $LinksiteID, $LinkUrl, $Comment, $Status))
		{
			$objUser->redirect('campaigns.php');
		}
	}

	$htmlPage = file_get_contents('../html/managesubmission.html');	
	
	$title = 'Add Linksite';
	$headText = 'Add a Linksite';
	$buttonText = 'ADD LINKSITE';
	$submitName = 'addsubmission';
	
	$getUser = ($objUser->getUser($_SESSION['UserID']));
	$CustomerID = $_SESSION['CustomerID'];
			
	$userFirstName = $getUser['firstname'];
	$userLastName = $getUser['lastname'];
	
	$campaigns = '<li><a href="../tool/campaigns.php">Campaigns</a></li>';
	$linksites = '<li><a href="../tool/linksites.php">Linksites</a></li>';
	$moderate = '<li class="active"><a href="../tool/moderate.php">Admin <span class="sr-only">(current)</span></a></li>';

	
	$errorDiv = '<div class="alert alert-danger">
				<i class="fa fa-exclamation-triangle"></i> &nbsp; '. $error .'
			</div>';
			
	$getLinksites = $objUser->getLinksites($CustomerID);
	
	$linksiteList = "";
	foreach ($getLinksites as $linksite)
	{
		$linksiteList .= '<option value="'.$linksite['name'].'">'. $linksite['name'] .'</option>';
	}
	
	$htmlPage = str_replace('%showAllLinksites%', $linksiteList, $htmlPage);
				
	if(empty($error))
	{
		$htmlPage = str_replace('%error%', '', $htmlPage);
	} else {
		$htmlPage = str_replace('%error%', $errorDiv, $htmlPage);
	}
	
	$htmlPage = str_replace('%campaigns%', $campaigns, $htmlPage);
	$htmlPage = str_replace('%linksites%', $linksites, $htmlPage);
	$htmlPage = str_replace('%admin%', $moderate, $htmlPage);
	
	$htmlPage = str_replace('%title%', $title, $htmlPage);
	$htmlPage = str_replace('%headText%', $headText, $htmlPage);
	$htmlPage = str_replace('%buttonText%', $buttonText, $htmlPage);
	$htmlPage = str_replace('%submitname%', $submitName, $htmlPage);
	$htmlPage = str_replace('%userFirstName%', $userFirstName, $htmlPage);
	$htmlPage = str_replace('%userLastName%', $userLastName, $htmlPage);


	/*$campaignlist = "";
	$getCampaignsites = $objUser->getCampaigns($CustomerID);
	foreach ($getCampaignsites as $campaign) {
		$campaignlist .= '<option value="'.$campaign['id'].'">'. $campaign['name'] .'</option>';
	}

	$htmlPage = str_replace('%listCampaigns%', $campaignlist, $htmlPage);*/
	
	echo $htmlPage;
}