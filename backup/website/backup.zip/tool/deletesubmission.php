<?php
	
require_once '../config.php';

if(!isset($_SESSION['UserID']))
{
	header('Location: ../offline/offline.html');
} else {
	if(empty($_GET['submission'])) {
		echo 'und waar denk jij naartoe te gaan';
	} else {
		$UserID = $_SESSION['UserID'];
		$hasAccess = ($hasPermission->isSuperuser($UserID));
		
		if($hasAccess)
		{
			$objUser->deleteSubmission($_GET['submission']);
			
			$objUser->redirect('campaigns.php');
		} else {
			
			$htmlPage = file_get_contents('../offline/denied.html');
			$title = 'Denied';		
			echo $htmlPage;
		}
	}
}