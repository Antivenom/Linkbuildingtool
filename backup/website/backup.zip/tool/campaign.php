<?php
	
require_once '../config.php';

if(!isset($_SESSION['UserID']))
{
	header('Location: ../offline/offline.html');
} else {
	if(empty($_GET['campaign'])) {
		echo 'und waar denk jij naartoe te gaan';
	} else {
		if(!$hasPermission->Campaign($_GET['campaign'], $_SESSION['CustomerID']))
		{
			header('Location: ../offline/denied.html');
		} else {
			$UserID = $_SESSION['UserID'];
			$noSuperUser = !$hasPermission->isSuperuser($UserID);
			
			if($noSuperUser)
			{
				$campaign = $objUser->getCampaign($_GET['campaign']);
			
				$CampaignID = $_GET['campaign'];
				$getCampaign = $objUser->getCampaign($CampaignID);
				
				$getUser = ($objUser->getUser($_SESSION['UserID']));
				
				$title = 'Viewing Campaign';
				
				$campaigns = '<li class="active"><a href="../tool/campaigns.php">Campaigns <span class="sr-only">(current)</span></a></li>';
				$linksites = '<li><a href="../tool/linksites.php">Linksites</a></li>';
				$moderate = '';
				
				$userFirstName = $getUser['firstname'];
				$userLastName = $getUser['lastname'];
				
				$htmlPage = file_get_contents('../html/campaign.html');
				
				$htmlPage = str_replace('%title%', $title, $htmlPage);
				$htmlPage = str_replace('%campaigns%', $campaigns, $htmlPage);
				$htmlPage = str_replace('%linksites%', $linksites, $htmlPage);
				$htmlPage = str_replace('%admin%', $moderate, $htmlPage);
				
				$htmlPage = str_replace('%userFirstName%', $userFirstName, $htmlPage);
				$htmlPage = str_replace('%userLastName%', $userLastName, $htmlPage);
				
				$saveUrl = '../tool/savecampaigns.php';
				$htmlPage = str_replace('%saveUrl%', $saveUrl, $htmlPage);
				
				$campaignsHtml = "";
				$campaignsHtmlUrl = "";
				$campaignsHtmlEmail = "";
				$campaignsHtmlCategory = "";
				$campaignsHtmlOwner = "";
				$campaignsHtmlTitle = "";
				$campaignshtmlDesc = "";
				$campaignsHtmlEmailTemplate = "";
				
				foreach($getCampaign as $displayCampaign){
					$campaignsHtml .= $displayCampaign['name'];
					$campaignsHtmlUrl = $displayCampaign['url'];
					$campaignsHtmlEmail = $displayCampaign['email'];
					$campaignsHtmlCategory = $displayCampaign['category'];
					$campaignsHtmlOwner = $displayCampaign['owner'];
					$campaignsHtmlTitle = $displayCampaign['title'];
					$campaignshtmlDesc = $displayCampaign['description'];
					$campaignsHtmlEmailTemplate = $displayCampaign['email_template'];
				}
				
				
				$htmlPage = str_replace('%campaignName%', $campaignsHtml, $htmlPage);
				$htmlPage = str_replace('%campaignURL%', $campaignsHtmlUrl, $htmlPage);
				$htmlPage = str_replace('%campaignEmail%', $campaignsHtmlEmail, $htmlPage);
				$htmlPage = str_replace('%campaignCategory%', $campaignsHtmlCategory, $htmlPage);
				$htmlPage = str_replace('%campaignOwner%', $campaignsHtmlOwner, $htmlPage);
				$htmlPage = str_replace('%campaignTitle%', $campaignsHtmlTitle, $htmlPage);
				$htmlPage = str_replace('%campaignDescription%', $campaignshtmlDesc, $htmlPage);
				$htmlPage = str_replace('%campaignEmailTemplate%', $campaignsHtmlEmailTemplate, $htmlPage);
				
				$CustomerID = $_SESSION['CustomerID'];
				
				$getSubmissions = $objUser->getSubmissions($CampaignID);
				
				$angularData = "";
				foreach($getSubmissions as $submit)
				{	
					$angularData .= '
						{
							"id" : "'.$submit['id'].'",
							"name" : "'.$submit['name'].'",
					        "rating" : "'.$submit['rating'].'",
					        "comment" : "'.$submit['comment'].'",
					        "linkurl" : "'.$submit['link_url'].'"
						},';
				}
				
				$htmlPage = str_replace('%angularData%', $angularData, $htmlPage);
				
				echo $htmlPage;
				
			} else {
				$campaign = $objUser->getCampaign($_GET['campaign']);
			
				$CampaignID = $_GET['campaign'];
				$getCampaign = $objUser->getCampaign($CampaignID);
				
				$CustomerID = $_SESSION['CustomerID'];
				$getLinksites = $objUser->getLinksites($CustomerID);
				
				$getUser = ($objUser->getUser($_SESSION['UserID']));
				
				$title = 'Viewing Campaign';
				
				$campaigns = '<li class="active"><a href="../tool/campaigns.php">Campaigns <span class="sr-only">(current)</span></a></li>';
				$linksites = '<li><a href="../tool/linksites.php">Linksites</a></li>';
				$moderate = '<li><a href="../tool/moderate.php">Admin</a></li>';
				
				$saveUrl = 'savecampaigns.php';
				$htmlPage = str_replace('%saveUrl%', $saveUrl, $htmlPage);
				
				
				$userFirstName = $getUser['firstname'];
				$userLastName = $getUser['lastname'];
				
				$htmlPage = file_get_contents('../html/campaign.html');
				
				$htmlPage = str_replace('%title%', $title, $htmlPage);
				$htmlPage = str_replace('%campaigns%', $campaigns, $htmlPage);
				$htmlPage = str_replace('%linksites%', $linksites, $htmlPage);
				$htmlPage = str_replace('%admin%', $moderate, $htmlPage);
				
				$htmlPage = str_replace('%userFirstName%', $userFirstName, $htmlPage);
				$htmlPage = str_replace('%userLastName%', $userLastName, $htmlPage);
				
				$campaignsHtml = "";
				$campaignsHtmlUrl = "";
				$campaignsHtmlEmail = "";
				$campaignsHtmlCategory = "";
				$campaignsHtmlOwner = "";
				$campaignsHtmlTitle = "";
				$campaignshtmlDesc = "";
				$campaignsHtmlEmailTemplate = "";
				
				foreach($getCampaign as $displayCampaign){
					$campaignsHtml .= $displayCampaign['name'];
					$campaignsHtmlUrl = $displayCampaign['url'];
					$campaignsHtmlEmail = $displayCampaign['email'];
					$campaignsHtmlCategory = $displayCampaign['category'];
					$campaignsHtmlOwner = $displayCampaign['owner'];
					$campaignsHtmlTitle = $displayCampaign['title'];
					$campaignshtmlDesc = $displayCampaign['description'];
					$campaignsHtmlEmailTemplate = $displayCampaign['email_template'];
				}

				$htmlPage = str_replace('%campaignName%', $campaignsHtml, $htmlPage);
				$htmlPage = str_replace('%campaignURL%', $campaignsHtmlUrl, $htmlPage);
				$htmlPage = str_replace('%campaignEmail%', $campaignsHtmlEmail, $htmlPage);
				$htmlPage = str_replace('%campaignCategory%', $campaignsHtmlCategory, $htmlPage);
				$htmlPage = str_replace('%campaignOwner%', $campaignsHtmlOwner, $htmlPage);
				$htmlPage = str_replace('%campaignTitle%', $campaignsHtmlTitle, $htmlPage);
				$htmlPage = str_replace('%campaignDescription%', $campaignshtmlDesc, $htmlPage);
				$htmlPage = str_replace('%campaignEmailTemplate%', $campaignsHtmlEmailTemplate, $htmlPage);


				$getSubmission = ($objUser->getSubmissionStatus($CampaignID));
				$submissionStatus = $getSubmission['status'];

				if($submissionStatus == "Not Submitted") {
					$htmlPage = str_replace('%selectedNotSubmitted%', 'selected', $htmlPage);
				} else {
					$htmlPage = str_replace('%selectedNotSubmitted%', '', $htmlPage);
				}

				if($submissionStatus == "Rejected") {
					$htmlPage = str_replace('%selectedRejected%', 'selected', $htmlPage);
				} else {
					$htmlPage = str_replace('%selectedRejected%', '', $htmlPage);
				}

				if($submissionStatus == "Accepted") {
					$htmlPage = str_replace('%selectedAccepted%', 'selected', $htmlPage);
				} else {
					$htmlPage = str_replace('%selectedAccepted%', '', $htmlPage);
				}

				if($submissionStatus == "Submitted") {
					$htmlPage = str_replace('%selectedSubmitted%', 'selected', $htmlPage);
				} else {
					$htmlPage = str_replace('%selectedSubmitted%', '', $htmlPage);
				}

				if($submissionStatus == "Failed") {
					$htmlPage = str_replace('%selectedFailed%', 'selected', $htmlPage);
				} else {
					$htmlPage = str_replace('%selectedFailed%', '', $htmlPage);
				}
				
										
				$getSubmissions = $objUser->getSubmissions($CampaignID);
				$angularData = "";
				$getLinkSite = "";
				foreach($getSubmissions as $submit)
				{	
					$angularData .= '
						{
							"id" : "'.$submit['id'].'",
							"linksites_id" : "'.$submit['linksites_id'].'",
							"name" : "'.$submit['name'].'",
					        "history" : "'.$submit['bot_updated'].'",
					        "rating" : "'.$submit['rating'].'",
					        "comment" : "'.$submit['comment'].'",
					        "linkurl" : "'.$submit['link_url'].'"
						},';
						
					$getLinkSite .= $submit['status'];
				}
				
				$htmlPage = str_replace('%angularData%', $angularData, $htmlPage);
				$htmlPage = str_replace('%status%', $getLinkSite, $htmlPage);
				
				echo $htmlPage;
			}
		}
	}
}