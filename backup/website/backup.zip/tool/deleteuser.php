<?php
	
require_once '../config.php';

if(!isset($_SESSION['UserID']))
{
	header('Location: ../offline/offline.html');
} else {
	if(empty($_GET['user'])) {
		echo 'und waar denk jij naartoe te gaan';
	} else {
		$UserID = $_SESSION['UserID'];
		$permission = $hasPermission->manageUser($UserID);
		
		if(!$permission)
		{
			$htmlPage = file_get_contents('../offline/denied.html');
			$title = 'Denied';		
			echo $htmlPage;
		} else {
			$objUser->deleteUser($_GET['user']);
			
			$objUser->redirect('users.php');
		}
	}
}