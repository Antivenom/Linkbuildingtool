<?php
	
require_once '../config.php';

if(!isset($_SESSION['UserID']))
{
	header('Location: ../offline/offline.html');
} else {
	$UserID = $_SESSION['UserID'];
	$permission = $hasPermission->isSuperuser($UserID);
	
	if(!$permission)
	{
		$htmlPage = file_get_contents('../html/toolindex.html');
		$title = 'Home';
		$userName = ($objUser->getUser($_SESSION['UserID'])['firstname']);
		$campaigns = '<li><a href="../tool/campaigns.php">Campaigns</a></li>';
		$linksites = '<li><a href="../tool/linksites.php">Linksites</a></li>';
		$moderate = '';
		$getUser = ($objUser->getUser($_SESSION['UserID']));
		$userFirstName = $getUser['firstname'];
		$userLastName = $getUser['lastname'];
		
		if($getUser = $permission)
		{
			$htmlPage = str_replace('%amISU%', 'Status: Admin', $htmlPage);
		} else {
			$htmlPage = str_replace('%amISU%', 'Status: User', $htmlPage);
		}
		
		$CustomerID = $_SESSION['CustomerID'];
		$amountOfCampaigns = 'Amount of Campaigns: '. $objUser->countAllCampaigns($CustomerID);
		$amountOfLinksites = 'Amount of Linksites: '. $objUser->countAllLinksites($CustomerID);
		
		$htmlPage = str_replace('%amountOfCampaigns%', $amountOfCampaigns, $htmlPage);
		$htmlPage = str_replace('%amountOfLinksites%', $amountOfLinksites, $htmlPage);
		
		$htmlPage = str_replace('%title%', $title, $htmlPage);
		$htmlPage = str_replace('%home%', $home, $htmlPage);
		$htmlPage = str_replace('%campaigns%', $campaigns, $htmlPage);
		$htmlPage = str_replace('%linksites%', $linksites, $htmlPage);
		$htmlPage = str_replace('%admin%', $moderate, $htmlPage);
		$htmlPage = str_replace('%userFirstName%', $userFirstName, $htmlPage);
		$htmlPage = str_replace('%userLastName%', $userLastName, $htmlPage);
		
		$htmlPage = str_replace('%userName%', $userName, $htmlPage);
		
		echo $htmlPage;
	} else {
		$htmlPage = file_get_contents('../html/toolindex.html');
		$title = 'Home';
		$userName = ($objUser->getUser($_SESSION['UserID'])['firstname']);
		$campaigns = '<li><a href="../tool/campaigns.php">Campaigns</a></li>';
		$linksites = '<li><a href="../tool/linksites.php">Linksites</a></li>';
		$moderate = '<li><a href="../tool/moderate.php">Admin</a></li>';
		$getUser = ($objUser->getUser($_SESSION['UserID']));
		$userFirstName = $getUser['firstname'];
		$userLastName = $getUser['lastname'];
		
		if($getUser = $permission)
		{
			$htmlPage = str_replace('%amISU%', 'Status: Admin', $htmlPage);
		} else {
			$htmlPage = str_replace('%amISU%', 'Status: User', $htmlPage);
		}
		
		$CustomerID = $_SESSION['CustomerID'];
		$amountOfCampaigns = 'Amount of Campaigns: '. $objUser->countAllCampaigns($CustomerID);
		$amountOfLinksites = 'Amount of Linksites: '. $objUser->countAllLinksites($CustomerID);
		
		$htmlPage = str_replace('%amountOfCampaigns%', $amountOfCampaigns, $htmlPage);
		$htmlPage = str_replace('%amountOfLinksites%', $amountOfLinksites, $htmlPage);
		
		$htmlPage = str_replace('%title%', $title, $htmlPage);
		$htmlPage = str_replace('%home%', $home, $htmlPage);
		$htmlPage = str_replace('%campaigns%', $campaigns, $htmlPage);
		$htmlPage = str_replace('%linksites%', $linksites, $htmlPage);
		$htmlPage = str_replace('%admin%', $moderate, $htmlPage);
		$htmlPage = str_replace('%userFirstName%', $userFirstName, $htmlPage);
		$htmlPage = str_replace('%userLastName%', $userLastName, $htmlPage);
		
		$htmlPage = str_replace('%userName%', $userName, $htmlPage);
		
		echo $htmlPage;
	}
}
