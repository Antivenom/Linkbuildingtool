<?php
	
require_once '../config.php';

if(!isset($_SESSION['UserID']))
{
	header('Location: ../offline/offline.html');
} else {
	if(empty($_GET['campaign'])) {
		echo 'und waar denk jij naartoe te gaan';
	} else {
		$UserID = $_SESSION['UserID'];
		$CustomerID = $_SESSION['CustomerID'];
		$hasAccess = ($hasPermission->isSuperuser($UserID) && $hasPermission->Campaign($_GET['campaign'], $CustomerID));
		
		if($hasAccess)
		{
			$objUser->deleteCampaign($_GET['campaign']);
			
			$objUser->redirect('campaigns.php');
		} else {
			
			$htmlPage = file_get_contents('../offline/denied.html');
			$title = 'Denied';		
			echo $htmlPage;
		}
	}
}