<?php
	
require_once '../config.php';

if(!isset($_SESSION['UserID']))
{
	header('Location: ../index.php');
} else {
	if(empty($_GET['linksite'])) {
		header('HTTP/1.1 404 Not Found');
	} else {
		if(!$hasPermission->Linksite($_GET['linksite'], $_SESSION['CustomerID']))
		{
			header('HTTP/1.1 403 Forbidden');
		} else {
			$UserID = $_SESSION['UserID'];
			$noSuperUser = !$hasPermission->isSuperuser($UserID);
			
			if($noSuperUser)
			{
				$linksite = $objUser->getLinksite($_GET['linksite']);
			
				$htmlPage = file_get_contents('../html/linksite.html');
				
				$getUser = ($objUser->getUser($_SESSION['UserID']));
				
				$userFirstName = $getUser['firstname'];
				$userLastName = $getUser['lastname'];
				
				$htmlPage = str_replace('%userFirstName%', $userFirstName, $htmlPage);
				$htmlPage = str_replace('%userLastName%', $userLastName, $htmlPage);
				
				$campaigns = '<li class="active"><a href="../tool/campaigns.php">Campaigns <span class="sr-only">(current)</span></a></li>';
				$linksites = '<li><a href="../tool/linksites.php">Linksites</a></li>';
				$moderate = '<li><a href="../tool/moderate.php">Admin</a></li>';
				$htmlPage = str_replace('%campaigns%', $campaigns, $htmlPage);
				$htmlPage = str_replace('%linksites%', $linksites, $htmlPage);
				$htmlPage = str_replace('%admin%', $moderate, $htmlPage);
				
				echo $htmlPage;
			} else {
				$linksite = $objUser->getLinksite($_GET['linksite']);
			
				$htmlPage = file_get_contents('../html/linksite.html');
				
				$getUser = ($objUser->getUser($_SESSION['UserID']));
				
				$userFirstName = $getUser['firstname'];
				$userLastName = $getUser['lastname'];
				
				$htmlPage = str_replace('%userFirstName%', $userFirstName, $htmlPage);
				$htmlPage = str_replace('%userLastName%', $userLastName, $htmlPage);
				
				$campaigns = '<li><a href="../tool/campaigns.php">Campaigns</a></li>';
				$linksites = '<li class="active"><a href="../tool/linksites.php">Linksites  <span class="sr-only">(current)</span></a></li>';
				$moderate = '<li><a href="../tool/moderate.php">Admin</a></li>';
				$htmlPage = str_replace('%campaigns%', $campaigns, $htmlPage);
				$htmlPage = str_replace('%linksites%', $linksites, $htmlPage);
				$htmlPage = str_replace('%admin%', $moderate, $htmlPage);
				
				echo $htmlPage;
			}
		}
	}
}