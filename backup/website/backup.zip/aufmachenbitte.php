+++<?php

require_once 'config.php';

if($objUser->isLoggedIn() != "")
{
	$objUser->redirect('index.php');
}

if(isset($_POST['register']))
{
	$strUsername = trim($_POST['username']);
	$strEmail = trim($_POST['email']);
	$Password = trim($_POST['password']);
	$strFirstname = trim($_POST['firstname']);
	$strLastname = trim($_POST['lastname']);
	
	if($strUsername == "")
	{
		$error[] = "Please enter a username.";
	}
	
	else if($strEmail == "")
	{
		$error[] = "Please enter an email address.";
	}
	
	else if(!filter_var($strEmail, FILTER_VALIDATE_EMAIL))
	{
		$error[] = "Please enter a valid email address.";
	}
	
	else if($Password == "")
	{
		$error[] = "Please enter a password.";
	}
	
	else if(strlen($Password) < 6)
	{
		$error[] = "The password must be at least 6 characters.";
	}
	
	else
	{
		try
		{
			$stmt = $objDB_con->prepare("
				SELECT username, email
				FROM users
				WHERE
				username = :username
				OR
				email = :email
			");
			
			$stmt->execute(array(
				':username' => $strUsername,
				':email' => $strEmail
			));
			
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			if($row['username'] == $strUsername)
			{
				$error[] = 'Sorry, username already exists.';
			}
			
			else if($row['email'] == $strEmail)
			{
				$error[] = 'Sorry, email already exists.';
			}
			
			else
			{
				if($objUser->register($strUsername, $strFirstname, $strLastname, $strEmail, $Password))
				{
					$objUser->redirect('register.php?joined');
				}
			}
		} catch(PDOException $e) {
			echo $e->getMessage();
		}
	}
}

?>

<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		
		<title>Registreer - Linkmanagement</title>
		
		<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css"  />
		<link rel="stylesheet" href="css/style.css" type="text/css"  />
	</head>
	<body>
		<div class="container">
			<div class="form-container">
				<form method="POST">
					<h2>Register</h2>
		            <?php
					if(isset($error))
					{
					 	foreach($error as $error)
					 	{
							 ?>
		                     <div class="alert alert-danger">
		                        <i class="glyphicon glyphicon-warning-sign"></i> &nbsp; <?php echo $error; ?>
		                     </div>
		                     <?php
						}
					}
					else if(isset($_GET['joined']))
					{
						 ?>
		                 <div class="alert alert-info">
		                      <i class="glyphicon glyphicon-log-in"></i> &nbsp; Succesvol geregistreerd log <a href='index.php'>hier</a> in
		                 </div>
		                 <?php
					}
					?>
					<div class="form-group">
						<input type="text" class="form-control" name="username" placeholder="Username" value="<?php if(isset($error)) { echo $strUsername; } ?>" />
					</div>
					
					<div class="form-group">
						<input type="text" class="form-control" name="email" placeholder="Email" value="<?php if(isset($error)) { echo $strEmail; } ?>" />
					</div>
					
					<div class="form-group">
						<input type="password" class="form-control" name="password" placeholder="Password" />
					</div>
					
					<div class="form-group">
						<input type="text" class="form-control" name="firstname" placeholder="Firstname"  />
					</div>
					
					<div class="form-group">
						<input type="text" class="form-control" name="lastname" placeholder="Lastname" />
					</div>
					
					<div class="clearfix"></div><hr />
					
					<div class="form-group">
						<button type="submit" class="btn btn-block btn-primary" name="register">
							<i class="glyphicon glyphicon-open-file"></i> &nbsp; Register
						</button>
					</div>
					<br />
					<label> Already have an account? <a href="index.php"> Log In </a></label>
				</form>				
			</div>
		</div>
	</body>
</html>