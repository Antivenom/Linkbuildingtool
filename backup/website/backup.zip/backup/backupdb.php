<?php

include '../class/backupdb.class.php';

try {
    $databaseDumper = Shuttle_Dumper::create(array(
        'host' => 'localhost',
        'username' => 'testssit',
        'password' => 'f2j7f4Mx',
        'db_name' => 'testssit_1',
    ));

    $databaseDumper->dump('database/database.sql');

    echo 'Finished.';
} catch(Shuttle_Exception $e) {
    echo "Couldn't dump database: " . $e->getMessage();
}